raise ImportError('''
Cython extension module 'pymor.tools.relations' has not been built.
Please run 'python setup.py build_ext --inplace' in the root
directory of the pyMOR repository.''')
